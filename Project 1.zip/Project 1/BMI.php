<?php 
class BMI{
    public $bb;
    public $tb;
    
    function __construct($bb, $tb){
        $this->bb = $bb;
        $this->tb = $tb;
    }
    public function nilaiBMI(){
        return $this->bb / (($this->tb/100)**2); 
    }
    public function statusBMI(){
        if($this->nilaiBMI() < 18.5 && $this->nilaiBMI() >= 0){
            echo "Kekurangan Bobot";
        }
        elseif($this->nilaiBMI() < 24.9){
            echo "Sehat";
        }
        elseif($this->nilaiBMI() < 27){
            echo "Kelebihan Bobot";
        }
        elseif($this->nilaiBMI() <=30 ){
            echo "Obesitas 1";
        }
        elseif($this->nilaiBMI() >30 ){
            echo "Obesitas 2";
        }
        else {
            echo $this->nilaiBMI(). "Tidak Termasuk dalam Golongan BMI";
        }
    }
}
?>