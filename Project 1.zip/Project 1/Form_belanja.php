<?php
include_once 'header.php';
include_once 'sidebar.php';
?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header text-center">
      <h2>Form Belanja</h2>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- Default box -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Belanja Online</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
              <div class="card-body">

              <div class="container-fluid">
              <div class="row p-3">
              <div class="col-md-8">
              <form method="POST" action="Form_belanja.php">
              <div class="container">
                <div class="form-group row">
                <label for="costumer" class="col-4 col-form-label">Costumer</label> 
                  <div class="col-4">
                    <input id="costumer" name="costumer" placeholder="Nama Customer" type="text" class="form-control">
                  </div>
                </div>
                <div class="form-group row">
                  <label class="col-4">Pilih Produk</label> 
                  <div class="col-8">
                  <div class="custom-control custom-radio custom-control-inline">
                      <input name="produk" id="produk_0" type="radio" class="custom-control-input" value="tv"> 
                      <label for="produk_0" class="custom-control-label">TV</label>
                    </div>
                    <div class="custom-control custom-radio custom-control-inline">
                      <input name="produk" id="produk_1" type="radio" class="custom-control-input" value="kulkas"> 
                      <label for="produk_1" class="custom-control-label">KULKAS</label>
                    </div>
                    <div class="custom-control custom-radio custom-control-inline">
                      <input name="produk" id="produk_2" type="radio" class="custom-control-input" value="mesin"> 
                      <label for="produk_2" class="custom-control-label">MESIN CUCI</label>
                    </div>
                  </div>
                </div>
                <div class="form-group row">
                  <label class="col-4 col-form-label" for="jumlah">Jumlah</label> 
                  <div class="col-2">
                    <input id="jumlah" name="jumlah" placeholder="Jumlah" type="text" class="form-control">
                  </div>
                </div> 
                <div class="form-group row">
                  <div class="offset-4 col-8">
                    <button name="proses" value="Kirim" type="submit" class="btn btn-success">Kirim</button>
                  </div>
                </div>
              </div>
              </div>
              <div class="col-md-4">
              <div class="list-group">
                <a href="#" class="list-group-item list-group-item-action active" aria-current="true">
                  Daftar Harga
                </a>
                <a href="#" class="list-group-item list-group-item-action">TV : 4.200.000</a>
                <a href="#" class="list-group-item list-group-item-action">KULKAS : 3.100.000</a>
                <a href="#" class="list-group-item list-group-item-action">MESIN CUCI : 3.800.000</a>
                <a href="#" class="list-group-item list-group-item-action active" aria-current="true">
                  Harga Dapat Berubah Setiap Saat
                </a>
              </div>
              </div>
              </form>
              </div>
              <hr>

              <?php
              $proses = $_POST['proses'];
              $nama_costumer = $_POST['costumer'];
              $nama_produk = $_POST['produk'];
              $nilai_jumlah = $_POST['jumlah'];

              if ($nama_produk=='tv'){
                  $produk_nama = "TV";
              }elseif ($nama_produk=='kulkas'){
                  $produk_nama = "KULKAS";
              }elseif ($nama_produk=='mesin'){
                  $produk_nama = "MESIN CUCI";
              }

              if ($nama_produk == 'tv'){
                $total = 4200000;
              }elseif($nama_produk == 'kulkas'){
                $total = 3100000;
              }elseif($nama_produk == 'mesin'){
                $total = 3800000;
              }
              $total_harga = $total * $nilai_jumlah;
              echo "Nama Costumer : $nama_costumer";
              echo "<br/>Pilihan Produk : $produk_nama";
              echo "<br/>Jumlah beli : $nilai_jumlah";
              echo "<br/>Total Belanja : $total_harga";
              ?>
              </div>
              </html>

              </div>
              <!-- /.card-body -->
              <div class="card-footer">
              </div>
              <!-- /.card-footer-->
            </div>
            <!-- /.card -->
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
<?php 
require_once 'footer.php';
?>