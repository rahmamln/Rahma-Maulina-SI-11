<?php 
class Dosen_model extends CI_Model{
    public $id, $nama, $gender, $tmp_lahir, $tgl_lahir, $nidn, $pendidikan;
}
?>